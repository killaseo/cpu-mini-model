# data/

Ten katalog jest pusty w repozytorium.

Po preprocessingu lokalnie pojawią się m.in.:

- `data/tokenizer.json`
- `data/meta.json`
- `data/train/train.h5`
- `data/val/val.h5`

Nie commituj tych plików, ponieważ mogą zawierać informacje pochodzące z prywatnego korpusu.
