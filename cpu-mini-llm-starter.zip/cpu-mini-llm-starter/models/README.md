# models/

Ten katalog jest pusty w repozytorium.

Trening zapisuje tutaj checkpointy `.pt`, np.:

- `models/mini_llm_tiny.pt`
- `models/mini_llm_mini.pt`

Nie commituj checkpointów do publicznego repozytorium, chyba że świadomie publikujesz model.
