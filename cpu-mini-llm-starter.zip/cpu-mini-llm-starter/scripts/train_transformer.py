"""
Train a small transformer language model on CPU.

CPU-oriented features:
  - short contexts and small batches
  - gradient accumulation
  - checkpoint save on Ctrl+C/error
  - resume with FMINI_RESUME=1
  - vocab_size loaded from data/meta.json after preprocessing
"""

import os
import sys
import json
import time

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config.config import default_config
from model import build_model


def load_meta(cfg):
    meta_path = "data/meta.json"
    if os.path.exists(meta_path):
        with open(meta_path, encoding="utf-8") as f:
            meta = json.load(f)
        cfg["vocab_size"] = int(meta["vocab_size"])
        print(f"From meta.json: vocab_size={cfg['vocab_size']}, tokenizer={meta['tokenizer']}")
    else:
        print(f"[WARNING] Missing {meta_path}; using fallback vocab_size={cfg['vocab_size']}.")
    return cfg


def get_batch_iterator(data_path, batch_size, context_length, device="cpu"):
    import h5py
    with h5py.File(data_path, "r") as f:
        data = f["tokens"][:]
    n = (len(data) - 1) // context_length
    if n < 1:
        raise SystemExit(f"Not enough tokens in {data_path} for context_length={context_length}.")
    idxs = np.arange(n)
    np.random.shuffle(idxs)
    counter = 0
    while True:
        if counter + batch_size > n:
            np.random.shuffle(idxs)
            counter = 0
        sel = idxs[counter:counter + batch_size] * context_length
        batch = np.stack([data[i:i + context_length + 1] for i in sel])
        batch = torch.from_numpy(batch).long()
        xb = batch[:, :context_length].to(device)
        yb = batch[:, 1:context_length + 1].to(device)
        counter += batch_size
        yield xb, yb


@torch.no_grad()
def estimate_loss(model, cfg, steps):
    out = {}
    model.eval()
    for split, path in [("train", cfg["train_path"]), ("dev", cfg["dev_path"])]:
        it = get_batch_iterator(path, cfg["t_batch_size"], cfg["t_context_length"], cfg["device"])
        losses = torch.zeros(steps)
        for k in range(steps):
            xb, yb = next(it)
            _, loss = model(xb, yb)
            losses[k] = loss.item()
        out[split] = losses.mean().item()
    model.train()
    return out


def save_checkpoint(model, optimizer, cfg, losses, path, steps):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    torch.save({
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        "config": {k: cfg[k] for k in (
            "n_head", "n_embed", "context_length", "vocab_size", "n_blocks"
        )},
        "training_config": cfg,
        "losses": losses,
        "steps": int(steps),
    }, path)
    print(f"Saved model -> {path}")


def load_checkpoint_if_requested(model, optimizer, cfg):
    resume = os.environ.get("FMINI_RESUME", "0") == "1"
    losses = []
    start_step = 0
    path = cfg["t_out_path"]
    if not resume:
        return losses, start_step
    if not os.path.exists(path):
        print(f"RESUME requested but no checkpoint found at {path}; starting from zero.")
        return losses, start_step

    ckpt = torch.load(path, map_location=cfg["device"])
    ckpt_cfg = ckpt.get("config", {})
    expected = {k: cfg[k] for k in ("n_head", "n_embed", "context_length", "vocab_size", "n_blocks")}
    if ckpt_cfg != expected:
        raise SystemExit(
            "Checkpoint architecture/tokenizer does not match current config.\n"
            f"Checkpoint: {ckpt_cfg}\nCurrent:    {expected}\n"
            "Use the matching FMINI_PROFILE/tokenizer or start a new checkpoint."
        )

    model.load_state_dict(ckpt["model_state_dict"])
    if "optimizer_state_dict" in ckpt:
        optimizer.load_state_dict(ckpt["optimizer_state_dict"])
    losses = list(ckpt.get("losses", []))
    start_step = int(ckpt.get("steps", len(losses)))
    print(f"RESUME: loaded {path} from step {start_step}")
    return losses, start_step


def main():
    cfg = dict(default_config)
    cfg = load_meta(cfg)

    torch.set_num_threads(cfg["num_threads"])
    os.environ.setdefault("OMP_NUM_THREADS", str(cfg["num_threads"]))
    cfg["device"] = "cpu"

    model = build_model(cfg).to(cfg["device"])
    total = sum(p.numel() for p in model.parameters())
    print(f"Profile: {cfg.get('profile')} | output: {cfg['t_out_path']}")
    print(f"Model parameters: {total:,} (~{total * 16 / 1e6:.0f} MB incl. AdamW states, rough)")

    optimizer = torch.optim.AdamW(model.parameters(), lr=cfg["t_lr"])
    losses, start_step = load_checkpoint_if_requested(model, optimizer, cfg)

    accum = cfg["accum_steps"]
    print(f"Batch={cfg['t_batch_size']} x accum={accum} -> effective batch={cfg['t_batch_size'] * accum}")
    print(f"Training target: steps {start_step} -> {cfg['t_train_steps']}")

    batch_it = get_batch_iterator(cfg["train_path"], cfg["t_batch_size"], cfg["t_context_length"], cfg["device"])
    from tqdm import tqdm
    pbar = tqdm(range(start_step, cfg["t_train_steps"]))
    t0 = time.time()

    try:
        optimizer.zero_grad(set_to_none=True)
        last_step = start_step
        for step in pbar:
            xb, yb = next(batch_it)
            _, loss = model(xb, yb)
            (loss / accum).backward()
            losses.append(loss.item())
            last_step = step + 1

            if (step + 1) % accum == 0:
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                optimizer.step()
                optimizer.zero_grad(set_to_none=True)

            if step % 50 == 0 and losses:
                avg = float(np.mean(losses[-64:]))
                toks = max(1, (step - start_step + 1)) * cfg["t_batch_size"] * cfg["t_context_length"]
                tps = toks / (time.time() - t0 + 1e-9)
                pbar.set_description(f"loss {avg:.3f} | {tps:,.0f} tok/s")

            if step > start_step and step % cfg["t_eval_steps"] == 0:
                ev = estimate_loss(model, cfg, cfg["t_eval_iters"])
                print(f"\nStep {step}: train {ev['train']:.4f} | dev {ev['dev']:.4f}")
                save_checkpoint(model, optimizer, cfg, losses, cfg["t_out_path"], last_step)

            if step == cfg["t_lr_decay_step"]:
                for g in optimizer.param_groups:
                    g["lr"] = cfg["t_lr_decayed"]
                print(f"\nLR decay -> {cfg['t_lr_decayed']}")

    except (KeyboardInterrupt, Exception) as e:
        print(f"\nInterrupted ({type(e).__name__}): {e}")
        print("Saving emergency checkpoint...")
        save_checkpoint(model, optimizer, cfg, losses, cfg["t_out_path"], last_step)
        raise

    final_step = cfg["t_train_steps"]
    save_checkpoint(model, optimizer, cfg, losses, cfg["t_out_path"], final_step)
    if losses:
        print(f"Done. Final loss: {np.mean(losses[-64:]):.4f}")
    else:
        print("Done. No new training steps were run.")


if __name__ == "__main__":
    main()
