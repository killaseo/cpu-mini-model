"""Quick corpus size checker."""
import argparse
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument("corpus_dir")
args = ap.parse_args()

files = []
for ext in ("*.txt", "*.md", "*.json"):
    files.extend(Path(args.corpus_dir).rglob(ext))
chars = 0
for fp in files:
    try:
        chars += len(fp.read_text(encoding="utf-8"))
    except UnicodeDecodeError:
        chars += len(fp.read_text(encoding="latin-2"))
print(f"files: {len(files)}")
print(f"characters: {chars:,}")
print(f"rough size: {chars / 1024 / 1024:.2f} MB")
