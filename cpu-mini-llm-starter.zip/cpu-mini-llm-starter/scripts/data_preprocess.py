"""
Preprocess a text corpus into token IDs stored in HDF5.

Input files: .txt, .md, .json, recursively under --corpus_dir.
Output files by default:
  data/train/train.h5
  data/val/val.h5
  data/tokenizer.json
  data/meta.json

No training data is included in this repository. Use your own corpus.
"""

import os
import sys
import json
import glob
import argparse
from pathlib import Path

import numpy as np
import h5py
from tqdm import tqdm

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def read_documents(corpus_dir):
    docs = []
    patterns = ["**/*.txt", "**/*.md", "**/*.json"]
    files = []
    for pattern in patterns:
        files.extend(glob.glob(os.path.join(corpus_dir, pattern), recursive=True))
    files = sorted(set(files))
    if not files:
        raise SystemExit(f"No .txt/.md/.json files found in {corpus_dir}")

    for fp in files:
        try:
            raw = Path(fp).read_text(encoding="utf-8")
        except UnicodeDecodeError:
            raw = Path(fp).read_text(encoding="latin-2")

        if fp.endswith(".json"):
            try:
                obj = json.loads(raw)
                if isinstance(obj, dict) and "text" in obj:
                    docs.append(str(obj["text"]))
                elif isinstance(obj, list):
                    for item in obj:
                        if isinstance(item, dict) and "text" in item:
                            docs.append(str(item["text"]))
                        else:
                            docs.append(json.dumps(item, ensure_ascii=False))
                else:
                    docs.append(raw)
            except json.JSONDecodeError:
                docs.append(raw)
        else:
            docs.append(raw)

    docs = [d.strip() for d in docs if d and d.strip()]
    total_chars = sum(len(d) for d in docs)
    print(f"Loaded {len(docs)} documents from {len(files)} files.")
    print(f"Corpus size: {total_chars:,} characters.")
    return docs


def train_bpe(docs, vocab_size, out_path):
    from tokenizers import Tokenizer, models, trainers, pre_tokenizers, decoders

    tok = Tokenizer(models.BPE(unk_token="<unk>"))
    tok.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=True)
    tok.decoder = decoders.ByteLevel()
    trainer = trainers.BpeTrainer(
        vocab_size=vocab_size,
        special_tokens=["<unk>", "<|endoftext|>"],
        show_progress=True,
    )
    tok.train_from_iterator(docs, trainer=trainer)
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    tok.save(out_path)
    print(f"Trained BPE tokenizer: vocab={tok.get_vocab_size()}, saved to {out_path}")
    return tok


def encode_docs(docs, encode_fn, eot_id):
    stream = []
    for doc in tqdm(docs, desc="Tokenizing"):
        stream.extend(encode_fn(doc))
        stream.append(eot_id)
    return np.array(stream, dtype=np.int32)


def write_h5(tokens, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with h5py.File(path, "w") as f:
        f.create_dataset("tokens", data=tokens, dtype="i4")
    print(f"Saved {len(tokens):,} tokens -> {path}")


def split_documents(docs, val_frac):
    # With very small corpora, a document-level split can accidentally put the
    # only large file in validation. For smoke tests, use the same docs for both.
    if len(docs) < 10:
        print("Small-corpus mode: using all documents for train and val copy.")
        return docs, docs

    rng = np.random.default_rng(1337)
    idx = rng.permutation(len(docs))
    n_val = max(1, int(len(docs) * val_frac))
    val_docs = [docs[i] for i in idx[:n_val]]
    train_docs = [docs[i] for i in idx[n_val:]]
    return train_docs, val_docs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--corpus_dir", required=True, help="Directory with your corpus files")
    ap.add_argument("--tokenizer", default="bpe", choices=["bpe", "r50k_base"])
    ap.add_argument("--vocab_size", type=int, default=8000, help="BPE vocab size")
    ap.add_argument("--val_frac", type=float, default=0.1)
    ap.add_argument("--train_h5", default="data/train/train.h5")
    ap.add_argument("--val_h5", default="data/val/val.h5")
    ap.add_argument("--tokenizer_out", default="data/tokenizer.json")
    ap.add_argument("--meta_out", default="data/meta.json")
    args = ap.parse_args()

    docs = read_documents(args.corpus_dir)
    train_docs, val_docs = split_documents(docs, args.val_frac)
    print(f"Train: {len(train_docs)} docs, Val: {len(val_docs)} docs")

    if args.tokenizer == "bpe":
        tok = train_bpe(train_docs, args.vocab_size, args.tokenizer_out)
        eot_id = tok.token_to_id("<|endoftext|>")

        def encode_fn(text):
            return tok.encode(text).ids

        vocab_size = tok.get_vocab_size()
    else:
        import tiktoken
        enc = tiktoken.get_encoding("r50k_base")
        eot_id = enc.encode("<|endoftext|>", allowed_special={"<|endoftext|>"})[0]

        def encode_fn(text):
            return enc.encode(text, allowed_special={"<|endoftext|>"})

        vocab_size = 50304

    train_tokens = encode_docs(train_docs, encode_fn, eot_id)
    val_tokens = encode_docs(val_docs, encode_fn, eot_id)

    write_h5(train_tokens, args.train_h5)
    write_h5(val_tokens, args.val_h5)

    meta = {
        "tokenizer": args.tokenizer,
        "vocab_size": int(vocab_size),
        "tokenizer_path": args.tokenizer_out if args.tokenizer == "bpe" else None,
        "n_train_tokens": int(len(train_tokens)),
        "n_val_tokens": int(len(val_tokens)),
        "n_docs": int(len(docs)),
    }
    os.makedirs(os.path.dirname(args.meta_out), exist_ok=True)
    with open(args.meta_out, "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)

    print(f"\nMetadata saved -> {args.meta_out}")
    print(json.dumps(meta, ensure_ascii=False, indent=2))

    if meta["n_train_tokens"] < 100_000:
        print("\n[WARNING] Small corpus (<100k train tokens). Use it only for smoke tests.")
    if meta["n_train_tokens"] < 1000:
        print("[WARNING] This is too small even for normal tiny training.")


if __name__ == "__main__":
    main()
