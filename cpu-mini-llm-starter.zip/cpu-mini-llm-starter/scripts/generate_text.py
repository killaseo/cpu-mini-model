"""
Generate text from a trained checkpoint.

By default, the checkpoint path is read from config/config.py, so setting
FMINI_PROFILE=tiny loads models/mini_llm_tiny.pt unless --model-path is given.
"""

import os
import sys
import json
import argparse

import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config.config import default_config
from model import Transformer


def get_encoder():
    if not os.path.exists("data/meta.json"):
        raise SystemExit("Missing data/meta.json. Run scripts/data_preprocess.py first.")
    with open("data/meta.json", encoding="utf-8") as f:
        meta = json.load(f)

    if meta["tokenizer"] == "bpe":
        from tokenizers import Tokenizer
        tok = Tokenizer.from_file(meta["tokenizer_path"])
        eot = tok.token_to_id("<|endoftext|>")
        return (lambda s: tok.encode(s).ids, lambda ids: tok.decode(ids), eot)

    import tiktoken
    enc = tiktoken.get_encoding("r50k_base")
    eot = enc.encode("<|endoftext|>", allowed_special={"<|endoftext|>"})[0]
    return (lambda s: enc.encode(s, allowed_special={"<|endoftext|>"}), lambda ids: enc.decode(ids), eot)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model_path", "--model-path", default=None, help="Checkpoint path; defaults to config t_out_path")
    ap.add_argument("--input", default="", help="Prompt; empty = start from <|endoftext|>")
    ap.add_argument("--max_new_tokens", "--max-new-tokens", type=int, default=150)
    ap.add_argument("--temperature", type=float, default=0.8)
    ap.add_argument("--top_k", "--top-k", type=int, default=40)
    ap.add_argument("--seed", type=int, default=None)
    args = ap.parse_args()

    torch.set_num_threads(int(os.environ.get("FMINI_THREADS", "4")))
    if args.seed is not None:
        torch.manual_seed(args.seed)

    model_path = args.model_path or default_config["t_out_path"]
    if not os.path.exists(model_path):
        raise SystemExit(f"Checkpoint not found: {model_path}")

    print(f"Loading model: {model_path}")
    ckpt = torch.load(model_path, map_location="cpu")
    cfg = ckpt["config"]
    model = Transformer(
        n_head=cfg["n_head"],
        n_embed=cfg["n_embed"],
        context_length=cfg["context_length"],
        vocab_size=cfg["vocab_size"],
        n_blocks=cfg["n_blocks"],
    )
    model.load_state_dict(ckpt["model_state_dict"])
    model.eval()

    encode, decode, eot = get_encoder()
    ids = encode(args.input) if args.input else [eot]
    idx = torch.tensor(ids, dtype=torch.long)[None, :]

    with torch.no_grad():
        out = model.generate(
            idx,
            args.max_new_tokens,
            temperature=args.temperature,
            top_k=args.top_k,
        )
    print(decode(out[0].tolist()))


if __name__ == "__main__":
    main()
