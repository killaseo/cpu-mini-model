"""Inspect a .pt checkpoint without training."""
import argparse
import torch

ap = argparse.ArgumentParser()
ap.add_argument("model_path")
args = ap.parse_args()
ckpt = torch.load(args.model_path, map_location="cpu")
print("steps:", ckpt.get("steps"))
print("config:", ckpt.get("config"))
losses = ckpt.get("losses", [])
print("loss_count:", len(losses))
if losses:
    print("first_loss:", losses[0])
    print("last_loss:", losses[-1])
    print("last_64_avg:", sum(losses[-64:]) / min(64, len(losses)))
