#!/usr/bin/env bash
# Optional swap helper for CPU-only machines. Use only if you understand the impact.
# Run: sudo bash setup_swap.sh
set -euo pipefail

SWAPFILE=${SWAPFILE:-/swapfile}
SIZE_GB=${SIZE_GB:-12}

echo "== Before =="
free -h
swapon --show || true

if swapon --show | grep -q "$SWAPFILE"; then
  echo "Swapfile already active: $SWAPFILE"
else
  echo "Creating $SWAPFILE (${SIZE_GB}G)..."
  fallocate -l "${SIZE_GB}G" "$SWAPFILE" || dd if=/dev/zero of="$SWAPFILE" bs=1M count=$((SIZE_GB * 1024))
  chmod 600 "$SWAPFILE"
  mkswap "$SWAPFILE"
  swapon "$SWAPFILE"
  grep -q "$SWAPFILE" /etc/fstab || echo "$SWAPFILE none swap sw 0 0" >> /etc/fstab
fi

sysctl vm.swappiness=10
grep -q "vm.swappiness" /etc/sysctl.conf || echo "vm.swappiness=10" >> /etc/sysctl.conf

echo "== After =="
free -h
swapon --show
