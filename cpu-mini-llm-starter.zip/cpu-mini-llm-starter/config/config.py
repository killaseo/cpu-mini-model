"""
CPU-friendly configuration for a tiny transformer language model.

The package is designed for people without a strong GPU. Everything defaults

to CPU, short contexts and gradient accumulation.

Main environment variables:
  FMINI_PROFILE      tiny | mini | small
  FMINI_THREADS      number of CPU threads, e.g. 4
  FMINI_TRAIN_STEPS  total target steps
  FMINI_RESUME       1 to resume from an existing checkpoint
  FMINI_RUN_NAME     prefix for checkpoint names
  FMINI_OUT_PATH     explicit checkpoint path
"""

import os

PROFILE = os.environ.get("FMINI_PROFILE", "mini")
RUN_NAME = os.environ.get("FMINI_RUN_NAME", "mini_llm")

TOKENIZER = os.environ.get("FMINI_TOKENIZER", "bpe")
BPE_VOCAB_SIZE = int(os.environ.get("FMINI_BPE_VOCAB_SIZE", "8000"))

_PROFILES = {
    # ~2.46M params with vocab=8000. Good for smoke tests and old laptops.
    "tiny": dict(
        N_EMBED=128,
        N_HEAD=4,
        N_BLOCKS=2,
        CONTEXT_LENGTH=64,
        T_BATCH_SIZE=8,
        ACCUM_STEPS=2,
        T_TRAIN_STEPS=2000,
    ),
    # ~7.29M params with vocab=8000. Recommended first real CPU model.
    "mini": dict(
        N_EMBED=256,
        N_HEAD=4,
        N_BLOCKS=4,
        CONTEXT_LENGTH=128,
        T_BATCH_SIZE=8,
        ACCUM_STEPS=4,
        T_TRAIN_STEPS=20000,
    ),
    # ~16.87M params with vocab=8000. Try only if RAM/swap is comfortable.
    "small": dict(
        N_EMBED=384,
        N_HEAD=6,
        N_BLOCKS=6,
        CONTEXT_LENGTH=192,
        T_BATCH_SIZE=4,
        ACCUM_STEPS=8,
        T_TRAIN_STEPS=30000,
    ),
}

if PROFILE not in _PROFILES:
    raise ValueError(f"Unknown FMINI_PROFILE={PROFILE!r}. Use: tiny, mini, small")

_p = _PROFILES[PROFILE]

CONTEXT_LENGTH = _p["CONTEXT_LENGTH"]
N_EMBED = _p["N_EMBED"]
N_HEAD = _p["N_HEAD"]
N_BLOCKS = _p["N_BLOCKS"]

# Scripts overwrite this from data/meta.json after preprocessing.
VOCAB_SIZE = BPE_VOCAB_SIZE if TOKENIZER == "bpe" else 50304

TRAIN_PATH = os.environ.get("FMINI_TRAIN_PATH", "data/train/train.h5")
DEV_PATH = os.environ.get("FMINI_DEV_PATH", "data/val/val.h5")
T_OUT_PATH = os.environ.get("FMINI_OUT_PATH", f"models/{RUN_NAME}_{PROFILE}.pt")

T_BATCH_SIZE = int(os.environ.get("FMINI_BATCH_SIZE", str(_p["T_BATCH_SIZE"])))
ACCUM_STEPS = int(os.environ.get("FMINI_ACCUM_STEPS", str(_p["ACCUM_STEPS"])))
T_CONTEXT_LENGTH = int(os.environ.get("FMINI_CONTEXT_LENGTH", str(CONTEXT_LENGTH)))

T_TRAIN_STEPS = int(os.environ.get("FMINI_TRAIN_STEPS", str(_p["T_TRAIN_STEPS"])))
T_EVAL_STEPS = int(os.environ.get("FMINI_EVAL_STEPS", "500"))
T_EVAL_ITERS = int(os.environ.get("FMINI_EVAL_ITERS", "50"))

T_LR = float(os.environ.get("FMINI_LR", "3e-4"))
T_LR_DECAY_STEP = int(os.environ.get("FMINI_LR_DECAY_STEP", str(int(T_TRAIN_STEPS * 0.6))))
T_LR_DECAYED = float(os.environ.get("FMINI_LR_DECAYED", "3e-5"))

DEVICE = os.environ.get("FMINI_DEVICE", "cpu")
NUM_THREADS = int(os.environ.get("FMINI_THREADS", "4"))

default_config = {
    "profile": PROFILE,
    "run_name": RUN_NAME,
    "vocab_size": VOCAB_SIZE,
    "context_length": CONTEXT_LENGTH,
    "n_embed": N_EMBED,
    "n_head": N_HEAD,
    "n_blocks": N_BLOCKS,
    "train_path": TRAIN_PATH,
    "dev_path": DEV_PATH,
    "t_batch_size": T_BATCH_SIZE,
    "accum_steps": ACCUM_STEPS,
    "t_context_length": T_CONTEXT_LENGTH,
    "t_train_steps": T_TRAIN_STEPS,
    "t_eval_steps": T_EVAL_STEPS,
    "t_eval_iters": T_EVAL_ITERS,
    "t_lr_decay_step": T_LR_DECAY_STEP,
    "t_lr": T_LR,
    "t_lr_decayed": T_LR_DECAYED,
    "t_out_path": T_OUT_PATH,
    "device": DEVICE,
    "num_threads": NUM_THREADS,
    "tokenizer": TOKENIZER,
}
