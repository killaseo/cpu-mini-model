# License notice

Before publishing this repository, choose and add a proper license.

If this package contains code derived from another repository, verify the upstream license and attribution requirements before making the repository public.
