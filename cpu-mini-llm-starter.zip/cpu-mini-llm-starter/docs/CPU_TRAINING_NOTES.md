# Notatki o treningu na CPU

Ten projekt celowo używa małych profili i krótkiego kontekstu. Przy CPU największym problemem nie są same wagi modelu, ale aktywacje podczas treningu.

## Profile

- `tiny`: test pipeline'u, słabsze maszyny.
- `mini`: pierwszy realny profil.
- `small`: eksperyment, jeśli RAM/swap pozwala.

## Jak obniżyć zużycie RAM

1. Użyj `FMINI_PROFILE=tiny`.
2. Zmniejsz `FMINI_BATCH_SIZE`.
3. Zmniejsz `FMINI_CONTEXT_LENGTH`.
4. Zwiększ `FMINI_ACCUM_STEPS`, żeby zachować większy batch efektywny.
5. Zmniejsz `FMINI_THREADS`, jeśli system zaczyna thrashować.

## Monitoring

```bash
watch -n2 free -h
```

## Przerwanie treningu

`Ctrl+C` zapisuje checkpoint awaryjny. Potem można wznowić:

```bash
FMINI_RESUME=1 FMINI_PROFILE=mini python scripts/train_transformer.py
```
