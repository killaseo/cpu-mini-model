# Format danych

Repozytorium nie zawiera danych treningowych. Użytkownik dostarcza własny katalog korpusu.

Obsługiwane rozszerzenia:

- `.txt`
- `.md`
- `.json`

## TXT / MD

Każdy plik jest traktowany jako osobny dokument.

## JSON jako obiekt

Jeśli JSON jest obiektem i zawiera pole `text`, skrypt użyje tego pola:

```json
{
  "title": "Example",
  "text": "Training text goes here."
}
```

## JSON jako lista

Jeśli JSON jest listą obiektów z polem `text`, każdy element zostanie potraktowany jako dokument:

```json
[
  {"text": "First document."},
  {"text": "Second document."}
]
```

## Minimalny rozmiar

- poniżej 100 KB: tylko smoke test,
- 1–10 MB: sensowny pierwszy trening,
- 10 MB+: dużo lepszy materiał.

## Prywatność

Nie commituj korpusów, `data/*.h5`, `data/tokenizer.json`, `data/meta.json` ani modeli `.pt`.
