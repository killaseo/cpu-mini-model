# Troubleshooting

## `Not enough tokens ... for context_length`

Korpus jest za mały albo preprocessing nie znalazł właściwych plików.

Sprawdź:

```bash
python scripts/count_corpus.py ./corpus
cat data/meta.json
```

## `Checkpoint not found`

Generator szuka checkpointu zgodnego z profilem. Sprawdź nazwę:

```bash
ls -lh models/
```

Albo wskaż ręcznie:

```bash
python scripts/generate_text.py --model-path models/mini_llm_tiny.pt --input "Start"
```

## Model generuje bełkot

Możliwe przyczyny:

- za krótki trening,
- za mały profil,
- za mały lub chaotyczny korpus,
- zbyt wysoka temperatura,
- zbyt wysokie `top_k`.

Spróbuj:

```bash
--top-k 10 --temperature 0.4
```

## Po zmianie korpusu wynik się popsuł

Po nowym preprocessingu zmienia się tokenizer. Stare checkpointy nie powinny być używane z nowym tokenizerem.

## System mocno zwalnia

Prawdopodobnie swapuje. Zmniejsz batch/context albo użyj mniejszego profilu.
