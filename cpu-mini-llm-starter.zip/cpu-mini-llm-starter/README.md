# CPU Mini LLM Starter

Minimalny, samowystarczalny projekt do trenowania małych modeli językowych typu transformer **od zera**, na zwykłym CPU, bez wymaganego dobrego GPU.

Projekt jest przeznaczony dla osób, które chcą:

- trenować własne małe modele na prywatnym korpusie tekstów,
- eksperymentować z tokenizerem BPE,
- sprawdzić pełny pipeline: `korpus → tokenizer → HDF5 → trening → checkpoint → generowanie`,
- uruchamiać eksperymenty na laptopie, mini PC, serwerze VPS albo starszej maszynie bez mocnej karty graficznej.

> **Ważne:** ta paczka nie zawiera żadnych danych treningowych, żadnych checkpointów i żadnych prywatnych tekstów. Użytkownik musi dostarczyć własny korpus.

---

## Co jest w paczce

```text
.
├── config/
│   └── config.py              # profile tiny/mini/small + ustawienia CPU
├── scripts/
│   ├── data_preprocess.py     # czyta korpus i tworzy tokenizer/HDF5
│   ├── train_transformer.py   # trening modelu na CPU
│   ├── generate_text.py       # generowanie tekstu z checkpointu
│   ├── count_corpus.py        # szybki licznik plików/znaków
│   └── check_checkpoint.py    # podgląd checkpointu/lossów
├── data/
│   ├── raw/                   # tu można wrzucić własny korpus lokalnie
│   ├── train/                 # wygenerowane train.h5, nie commitować
│   └── val/                   # wygenerowane val.h5, nie commitować
├── models/                    # wygenerowane .pt, nie commitować
├── model.py                   # mały transformer
├── requirements.txt           # zależności poza PyTorch
├── setup_swap.sh              # opcjonalny swap helper dla słabszych maszyn
└── README.md
```

---

## Czego nie ma w paczce

Nie ma tutaj:

- danych treningowych,
- plików `.h5`,
- `data/tokenizer.json`,
- `data/meta.json`,
- checkpointów `.pt`,
- żadnego prywatnego korpusu.

`.gitignore` celowo blokuje commitowanie danych i modeli.

---

## Wymagania

Minimalnie:

- Linux, macOS albo WSL,
- Python 3.10+,
- kilka GB wolnego RAM,
- trochę miejsca na dysku,
- CPU wystarczy.

Zalecane dla wygodnego testu:

- 8 GB RAM lub więcej,
- 4 wątki CPU,
- swap jako poduszka bezpieczeństwa,
- korpus tekstowy minimum 100 KB do testów, lepiej 1–10 MB+.

---

## Instalacja

```bash
python3 -m venv .venv
source .venv/bin/activate

python -m pip install --upgrade pip wheel setuptools
```

PyTorch CPU instaluj osobno:

```bash
pip install torch --index-url https://download.pytorch.org/whl/cpu
```

Pozostałe zależności:

```bash
pip install -r requirements.txt
```

Test składni:

```bash
python -m py_compile model.py config/config.py scripts/*.py && echo "OK"
```

---

## Przygotowanie własnego korpusu

Utwórz katalog z własnymi tekstami, np.:

```bash
mkdir -p ./corpus
```

Do katalogu możesz wrzucać:

- `.txt`,
- `.md`,
- `.json`.

Dla JSON skrypt próbuje użyć pola `text`, jeśli istnieje. Obsługuje także listy obiektów z polem `text`.

Sprawdzenie rozmiaru korpusu:

```bash
python scripts/count_corpus.py ./corpus
```

Orientacyjne progi:

```text
< 100 KB      tylko smoke test
100 KB–1 MB   minimalny eksperyment
1–10 MB       sensowny pierwszy trening
10 MB+        wyraźnie lepiej
```

---

## Preprocessing

Domyślnie używany jest własny tokenizer BPE z vocabem 8000 tokenów.

```bash
python scripts/data_preprocess.py --corpus_dir ./corpus
```

Powstaną pliki:

```text
data/tokenizer.json
data/meta.json
data/train/train.h5
data/val/val.h5
```

Te pliki są generowane lokalnie i nie powinny trafiać do repozytorium.

---

## Profile modeli

Domyślne profile są dobrane pod CPU:

| Profil | Parametry przy vocab=8000 | Zastosowanie |
|---|---:|---|
| `tiny` | ok. 2.46M | smoke test, słaby laptop, szybkie sprawdzenie pipeline'u |
| `mini` | ok. 7.29M | zalecany pierwszy realny model CPU |
| `small` | ok. 16.87M | eksperyment, jeśli RAM/swap pozwala |

---

## Trening: pierwszy smoke test

Najpierw sprawdź, czy całość działa na `tiny`:

```bash
FMINI_PROFILE=tiny \
FMINI_THREADS=4 \
FMINI_TRAIN_STEPS=500 \
FMINI_EVAL_STEPS=100 \
FMINI_EVAL_ITERS=2 \
python scripts/train_transformer.py
```

Checkpoint zapisze się domyślnie jako:

```text
models/mini_llm_tiny.pt
```

---

## Trening dłuższy

Dla `tiny`:

```bash
FMINI_PROFILE=tiny \
FMINI_THREADS=4 \
FMINI_TRAIN_STEPS=10000 \
FMINI_EVAL_STEPS=1000 \
FMINI_EVAL_ITERS=10 \
python scripts/train_transformer.py
```

Dla `mini`:

```bash
FMINI_PROFILE=mini \
FMINI_THREADS=4 \
FMINI_TRAIN_STEPS=5000 \
FMINI_EVAL_STEPS=500 \
FMINI_EVAL_ITERS=5 \
python scripts/train_transformer.py
```

Jeśli sprzęt daje radę, możesz dociągnąć `mini` dalej:

```bash
FMINI_PROFILE=mini \
FMINI_RESUME=1 \
FMINI_THREADS=4 \
FMINI_TRAIN_STEPS=20000 \
FMINI_EVAL_STEPS=2000 \
FMINI_EVAL_ITERS=10 \
python scripts/train_transformer.py
```

---

## Resume treningu

Jeśli trening został przerwany albo chcesz go kontynuować:

```bash
FMINI_PROFILE=mini \
FMINI_RESUME=1 \
FMINI_TRAIN_STEPS=20000 \
python scripts/train_transformer.py
```

`FMINI_TRAIN_STEPS` oznacza docelowy numer kroku, a nie liczbę dodatkowych kroków. Jeśli checkpoint ma 5000 kroków, a ustawisz `FMINI_TRAIN_STEPS=20000`, trening pójdzie od 5000 do 20000.

---

## Generowanie tekstu

Dla `tiny`:

```bash
FMINI_PROFILE=tiny \
python scripts/generate_text.py \
  --input "Początek tekstu" \
  --max-new-tokens 120 \
  --top-k 10 \
  --temperature 0.45
```

Dla `mini`:

```bash
FMINI_PROFILE=mini \
python scripts/generate_text.py \
  --input "Once upon a time" \
  --max-new-tokens 160 \
  --top-k 20 \
  --temperature 0.55
```

Możesz wskazać checkpoint ręcznie:

```bash
python scripts/generate_text.py \
  --model-path models/mini_llm_mini.pt \
  --input "Start" \
  --max-new-tokens 160
```

---

## Jak interpretować loss

Przy vocab=8000 startowy losowy loss jest blisko:

```text
ln(8000) ≈ 8.99
```

Orientacyjnie:

```text
8–7   model prawie losowy, łapie najczęstsze tokeny
7–6   zaczyna łapać częste konstrukcje języka
6–5   powinno być widać coraz więcej składni
<5    zależy od korpusu, ale wynik robi się wyraźnie ciekawszy
```

Mały model trenowany na małym lub monotonnym korpusie będzie wpadał w pętle. To normalne.

---

## Monitorowanie RAM

W drugim terminalu:

```bash
watch -n2 free -h
```

Jeżeli system zaczyna mocno swapować i spowalniać:

- zmniejsz batch,
- zmniejsz context length,
- użyj profilu `tiny`,
- zmniejsz `FMINI_THREADS`,
- przerwij trening `Ctrl+C` — skrypt zapisze checkpoint awaryjny.

---

## Opcjonalny swap

Na Linuxie możesz użyć helpera:

```bash
sudo bash setup_swap.sh
```

Domyślnie tworzy `/swapfile` 12 GB i ustawia niższy `swappiness`. To jest tylko poduszka bezpieczeństwa, nie zamiennik RAM.

---

## Zmienne środowiskowe

Najważniejsze:

| Zmienna | Przykład | Znaczenie |
|---|---|---|
| `FMINI_PROFILE` | `tiny`, `mini`, `small` | wybór profilu |
| `FMINI_THREADS` | `4` | liczba wątków CPU |
| `FMINI_TRAIN_STEPS` | `10000` | docelowa liczba kroków |
| `FMINI_RESUME` | `1` | wznawianie checkpointu |
| `FMINI_RUN_NAME` | `my_model` | prefiks nazwy checkpointu |
| `FMINI_OUT_PATH` | `models/x.pt` | ręczna ścieżka checkpointu |
| `FMINI_BATCH_SIZE` | `4` | nadpisanie batch size |
| `FMINI_ACCUM_STEPS` | `8` | gradient accumulation |
| `FMINI_CONTEXT_LENGTH` | `128` | długość kontekstu treningowego |

---

## Ważna zasada: tokenizer i checkpoint

Po każdym nowym preprocessingu zmienia się `data/tokenizer.json`. Stary checkpoint może mieć ten sam `vocab_size`, ale tokeny mogą oznaczać coś innego. Dlatego po zmianie korpusu/tokenizera najlepiej trenować nowy model od zera albo bardzo świadomie pilnować zgodności.

---

## Bezpieczeństwo danych

Ta paczka jest przygotowana tak, aby repozytorium nie zawierało danych użytkownika. Przed publikacją sprawdź:

```bash
git status --ignored
find data models -type f -not -name '.gitkeep' -print
```

W repo powinny zostać tylko pliki kodu, dokumentacji i `.gitkeep`.

---

## Ograniczenia

To jest projekt edukacyjno-eksperymentalny. Nie zastąpi dużych modeli LLM. Jego celem jest:

- nauka pipeline'u LLM,
- trening bardzo małych modeli,
- eksperymenty z własnymi korpusami,
- praca lokalna na CPU.

Nie oczekuj jakości ChatGPT. Oczekuj małego, kontrolowanego laboratorium do własnych danych.
